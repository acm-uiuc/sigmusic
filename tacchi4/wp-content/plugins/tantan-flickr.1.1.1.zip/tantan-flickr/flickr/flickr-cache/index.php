<?php
/* this directory should be empty */
?>