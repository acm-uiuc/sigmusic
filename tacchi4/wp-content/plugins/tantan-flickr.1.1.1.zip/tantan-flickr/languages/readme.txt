Visit the link below to learn how you can help translate this plugin into your own language.

http://code.google.com/p/photo-album/wiki/Localization